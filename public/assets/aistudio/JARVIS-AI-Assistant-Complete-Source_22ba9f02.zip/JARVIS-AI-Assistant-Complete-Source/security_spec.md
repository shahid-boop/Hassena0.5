# Hasseena AI — Firestore Security Specification & Red Team Audit

## 1. Data Invariants
1. **Strict User Isolation**: Every memory fact (`/users/{userId}/memories/{memoryId}`) and conversation message (`/users/{userId}/messages/{messageId}`) belongs exclusively to `userId` where `request.auth != null && request.auth.uid == userId`.
2. **Identity Integrity**: Incoming payloads must set `userId == request.auth.uid` on creation and keep `userId` and `createdAt` immutable on updates.
3. **Path & Size Hardening**: All path IDs (`userId`, `memoryId`, `messageId`) must satisfy `isValidId(id)` (`size() <= 128` and `matches('^[a-zA-Z0-9_\\-]+$')`). All string fields must enforce explicit `.size()` bounds.
4. **Server Timestamp Enforcement**: `createdAt` and `updatedAt` must be Firestore `timestamp` values (`<= request.time`), written via `FieldValue.serverTimestamp()`.

## 2. The Dirty Dozen Payloads
1. **Unauthenticated Read/Write**: `request.auth == null` attempting `get`, `list`, `create`, `update`, or `delete` on `/users/alice_123/memories/m1`. (Rejected by `isSignedIn()`).
2. **Cross-User Read (`bob_456` reading `alice_123`)**: Authenticated as `bob_456` attempting `get` or `list` on `/users/alice_123/memories`. (Rejected by `request.auth.uid == userId`).
3. **Spoofed `userId` Field**: Authenticated as `alice_123` writing to `/users/alice_123/memories/m1` with `userId: "bob_456"`. (Rejected by `incoming().userId == request.auth.uid`).
4. **Shadow / Ghost Field Injection**: Adding `isAdmin: true` or `verified: true` to a memory or message document. (Rejected by `incoming().keys().hasOnly(...)`).
5. **Missing Required Keys**: Creating a memory without `content` or `createdAt`. (Rejected by `incoming().keys().hasAll(...)`).
6. **Oversized Content DoW Attack**: Sending a 50,000-character `content` string. (Rejected by `data.content.size() <= 8000`).
7. **Invalid Enum Category**: Creating a memory with `category: "HACKED_ROOT"`. (Rejected by `data.category in ['PREFERENCE', 'FACT', 'INSTRUCTION', 'HABIT']`).
8. **Invalid Message Role**: Creating a chat message with `role: "system_override"`. (Rejected by `data.role in ['user', 'assistant', 'tool']`).
9. **Epoch Long Timestamp Spoofing**: Passing `createdAt: 1700000000000` (integer) instead of a server `timestamp`. (Rejected by `data.createdAt is timestamp`).
10. **Future Timestamp Injection**: Passing a timestamp in the future (`> request.time`). (Rejected by `data.createdAt <= request.time`).
11. **Immutable Field Mutation on Update**: Updating `createdAt` or `userId` on an existing memory document. (Rejected by `incoming().userId == existing().userId && incoming().createdAt == existing().createdAt`).
12. **Malformed Document ID Poisoning**: Creating a document with special characters or length > 128 (`m$1/../../etc`). (Rejected by `isValidId(memoryId)`).
