HASSEENA AI — ELEVENLABS VOICE SETUP

The voice engine is connected to the assistant's online speech path. The app cannot automatically know private voice IDs from your ElevenLabs account unless they are fetched from the account API or entered by you.

Five independent packs are supported:
- Charmion (pack id: charmion)
- Hasseena Custom (pack id: hasseena_custom)
- Tiffany (pack id: tiffany)
- Aurora (pack id: aurora)
- Nyx (pack id: nyx)

Setup in the app:
1. Open Settings > Orb & Voice.
2. Paste your ElevenLabs API key and the selected pack's Voice ID.
3. Tap Save Voice Settings.
4. Tap Test Selected ElevenLabs Voice. A successful test means the API request returned audio and Android played it.
5. Repeat for each pack you actually have in your ElevenLabs account. Each pack stores its own ID.

Do not share your API key in chat or hardcode it into the project. The API key is stored encrypted using Android Keystore. The app falls back to Android TTS if online speech fails.

Build verification note: this ZIP was structurally packaged, but compile verification in this environment could not run because the Gradle wrapper distribution could not be downloaded (DNS/UnknownHostException for services.gradle.org). Build on the Termux device where Gradle is already installed.
