# JARVIS feature verification checklist

Status meanings: **SOURCE PRESENT** means code exists and was inspected; it does not mean device behavior passed. **BLOCKED** means runtime/build verification could not be run in this environment.

| Area | Source finding | Verification status |
|---|---|---|
| Native Android / Jetpack Compose | Existing Compose `MainActivity` and screens retained | SOURCE PRESENT; build BLOCKED |
| Black / neon-red theme | Existing theme token palette uses black surfaces and red accents | SOURCE PRESENT; visual/device check BLOCKED |
| Home / voice assistant | `HomeVoiceScreen`, `VoiceAssistantService`, foreground voice service | SOURCE PRESENT; microphone/device check BLOCKED |
| Chat / streaming | `ChatStreamScreen`, AI service streaming code | SOURCE PRESENT; provider/network check BLOCKED |
| AI model routing | `AIModelRouter` routes by task, provider configuration, and capabilities | SOURCE PRESENT; unit tests BLOCKED |
| Provider keys | `ApiKeyStore` uses Android Keystore AES-GCM; provider settings exist | SOURCE PRESENT; device crypto and live connection tests BLOCKED |
| Speech-to-text / text-to-speech | Android voice service plus Gemini/ElevenLabs player classes | SOURCE PRESENT; engine/API/permission checks BLOCKED |
| Android controls | App launch, Android control, accessibility and notification services exist | SOURCE PRESENT; permission and device action checks BLOCKED |
| Files / ZIP | SAF-based workspace and ZIP import/export code exist | SOURCE PRESENT; filesystem/device test BLOCKED |
| Research | Wikipedia, DuckDuckGo Instant Answers, Wikimedia retrieval and AI synthesis code exist | SOURCE PRESENT; live network research BLOCKED |
| Chat history / memory | Existing database and memory repository classes exist | SOURCE PRESENT; persistence tests BLOCKED |
| Automation / task persistence | Some command and task state flows exist; comprehensive end-to-end automation not verified | PARTIAL / BLOCKED |
| Dedicated Coding screen | Coding-agent workflow is surfaced from File Workspace; separate dedicated bottom-nav destination not found | NOT A SEPARATE SCREEN |
| Dedicated AI Providers screen | Provider configuration appears in Settings; separate dedicated bottom-nav destination not found | NOT A SEPARATE SCREEN |
| RAG ingestion / retrieval / citations | Not fully established from this pass; do not assume full document-grounded RAG coverage | NOT VERIFIED |
| Unit tests / Robolectric | Existing tests retained; prior bundled log shows four failures at `DefaultNativeRuntimeLoader.java:191` | BLOCKED in current environment |
| Debug APK | No SDK or downloadable Gradle distribution in current environment | BLOCKED; APK not included |

## High-impact changes in this repair pass
- Updated user-facing assistant strings to JARVIS while preserving internal identifiers.
- Updated stale app-name test expectation.
- Changed default wake phrase to “Hey JARVIS” while retaining the existing preference storage key.
- Removed bundled debug signing key and custom debug signing configuration; local AGP debug signing is used instead.
- Preserved existing feature code and tests; no failing tests were deleted.
