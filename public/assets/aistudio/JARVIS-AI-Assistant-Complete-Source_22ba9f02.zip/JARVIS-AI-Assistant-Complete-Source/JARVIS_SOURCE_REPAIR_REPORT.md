# JARVIS AI Assistant — source repair report

## Scope
This is a repair pass on the supplied Android source archive, not a new demo project. Existing package names, data keys, and service class identifiers were retained to reduce migration risk.

## Changes made in this pass
- Updated user-facing assistant copy in Kotlin string literals from Hasseena to JARVIS while preserving internal class/package identifiers.
- Updated the Robolectric app-name assertion to match the actual `JARVIS AI Assistant` string resource.
- Updated the default wake phrase to `Hey JARVIS`; the existing DataStore preference key is retained so existing installations remain compatible.
- Removed the bundled `debug.keystore` and custom debug-signing configuration. Android Gradle Plugin will generate/use the developer-local debug keystore, avoiding shipping a signing key in the source ZIP.
- Kept the existing AI router, encrypted API-key store, voice services, Android-control services, SAF file workspace, research service, Compose screens, and existing tests.

## Verified source observations
- Existing screens include Assistant/Voice, Chat, Visual Lens, Research, Control & Permissions, Files/Workspace, and Settings. Provider key management is surfaced within Settings; this archive does not show a separate dedicated AI Providers bottom-navigation destination.
- `ApiKeyStore` encrypts provider keys using Android Keystore AES-GCM and stores ciphertext in private SharedPreferences. `AIService` still supports BuildConfig fallback keys; do not put real credentials in `.env` or a distributed APK because APK BuildConfig values can be extracted. Prefer in-app user-supplied keys.
- `app/google-services.json` contains Firebase project identifiers (`gen-lang-client-0796915960`), which are configuration identifiers rather than service-account private keys. Confirm the project is yours before using Firebase-backed auth/sync.
- A prior included build log shows Kotlin compilation once failed at `FileWorkspaceScreen.kt:92`, then a later included log shows compilation and APK packaging succeeded before four Robolectric tests failed at `DefaultNativeRuntimeLoader.java:191`. Those logs describe an earlier environment/state, not this modified source build.

## Verification performed in this environment
| Check | Result | Evidence / limitation |
|---|---|---|
| ZIP extraction / source inventory | PASS | Archive opened; 136 entries were listed before cleanup. |
| Kotlin/source string update script | PASS | Applied to source string literals only; internal identifiers were not mass-renamed. |
| Android manifest and Gradle source inspection | PASS | Files inspected statically. |
| Current Gradle wrapper launch | BLOCKED | `bash gradlew --version` attempted to download Gradle 9.6.0 and failed with `java.net.UnknownHostException: services.gradle.org`. |
| Android SDK availability | BLOCKED | `ANDROID_HOME` is unset and no Android SDK platform was found in the environment. |
| Kotlin compile / debug APK / unit tests / lint | BLOCKED | Cannot execute without the Gradle distribution and Android SDK. No new APK is claimed. |
| Robolectric native-runtime issue | NOT VERIFIED HERE | Prior log attributes failures to `DefaultNativeRuntimeLoader.java:191`; without rerunning with the matching Gradle/dependency cache, root cause cannot be reliably attributed to app code versus host native-library setup. |
| Device/emulator flows | BLOCKED | No Android device/emulator is attached. |

## Remaining risks / limitations
- This pass does not claim all requested features are complete. A complete build/test pass is required in Android Studio or a network-enabled Android build environment.
- AI provider calls and web research require network access; most hosted providers require a valid user-owned API key and may charge or rate-limit. There is no unlimited-free-model guarantee.
- Microphone, camera, call, notification-listener, accessibility, overlay, contacts, calendar, and notification functions require appropriate Android permissions or user-enabled special access. Android may restrict direct SMS sending and background microphone behavior.
- Release builds require a user-owned release keystore and the corresponding `KEYSTORE_PATH`, `STORE_PASSWORD`, and `KEY_PASSWORD` environment variables. Never ship debug signing material.
- Confirm Firebase project ownership/configuration before enabling auth or cloud sync.

## Build instructions
1. Open this project folder in Android Studio with a compatible JDK (the project uses Java 11 source/target compatibility) and install the Android SDK required by `compileSdk` 36.
2. Let Android Studio sync Gradle; ensure the Gradle 9.6.0 distribution and dependencies can be downloaded.
3. Review `app/google-services.json` and replace it with your own Firebase configuration if needed. Keep real API keys out of source control.
4. Build debug APK: `./gradlew :app:assembleDebug` (Windows: `gradlew.bat :app:assembleDebug`).
5. Run unit tests: `./gradlew :app:testDebugUnitTest` (Windows: `gradlew.bat :app:testDebugUnitTest`).
6. Run lint: `./gradlew :app:lintDebug`.
7. Install a successfully built debug APK: `adb install -r app/build/outputs/apk/debug/app-debug.apk`.
