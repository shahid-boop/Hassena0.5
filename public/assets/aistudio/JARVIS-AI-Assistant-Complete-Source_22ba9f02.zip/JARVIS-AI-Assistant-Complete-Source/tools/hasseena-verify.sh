#!/data/data/com.termux/files/usr/bin/bash
set -o pipefail
cd "$(dirname "$0")/.." || exit 1
mkdir -p build-logs
LOG="build-logs/verify-$(date +%Y%m%d-%H%M%S).log"
echo "Unit tests aur debug APK build shuru. Log: $LOG"
if ./gradlew testDebugUnitTest assembleDebug --no-daemon 2>&1 | tee "$LOG"; then
  echo "VERIFY_SUCCESS: unit tests aur assembleDebug command successful."
  echo "APK: app/build/outputs/apk/debug/app-debug.apk"
  exit 0
else
  code=$?
  echo "VERIFY_FAILED: exit=$code"
  echo "Error log: $LOG"
  echo "Last 100 log lines:"
  tail -n 100 "$LOG"
  exit "$code"
fi
