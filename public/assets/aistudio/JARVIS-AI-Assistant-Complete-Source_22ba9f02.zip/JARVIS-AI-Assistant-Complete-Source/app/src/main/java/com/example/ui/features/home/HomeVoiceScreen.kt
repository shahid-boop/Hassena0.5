package com.example.ui.features.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.models.DeviceTelemetrySnapshot
import com.example.models.OrbConfig
import com.example.models.OrbState
import com.example.services.memory.HasseenaUserPreferences
import com.example.ui.theme.AmberThinking
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldReady
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.QuantumViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.widgets.orb.HasseenaOrb

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeVoiceScreen(
    orbState: OrbState,
    orbConfig: OrbConfig,
    audioLevel: Float,
    partialTranscript: String,
    voiceError: String?,
    liveHeadline: String,
    liveRouteBadge: String,
    lastLatencyMs: Long,
    isGenerating: Boolean,
    isFlashlightOn: Boolean,
    telemetry: DeviceTelemetrySnapshot,
    preferences: HasseenaUserPreferences,
    onTapOrb: () -> Unit,
    onLongPressOrb: () -> Unit,
    onInterrupt: () -> Unit,
    onSubmitCommand: (String) -> Unit,
    onToggleFlashlight: () -> Unit,
    onVolumeAdjust: (Boolean) -> Unit,
    onBrightnessPreset: (Int) -> Unit,
    onCopyResponse: (String) -> Unit,
    onSpeakResponse: (String) -> Unit,
    onOpenChatStream: () -> Unit
) {
    var commandText by rememberSaveable { mutableStateOf("") }
    val scrollState = rememberScrollState()

    val quickLocalCommands = listOf(
        "Turn on flashlight",
        "Turn off flashlight",
        "Show battery",
        "Increase volume",
        "Set brightness to 50",
        "Open YouTube",
        "Open Settings",
        "Open Camera",
        "Read screen",
        "Set timer for 5 minutes",
        "What time is it"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 1. TOP TELEMETRY & PROVIDER STATUS BAR
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(ObsidianSurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(50))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = "Active AI Engine",
                    tint = CyberCyan,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${preferences.selectedProvider.displayName} • ${preferences.routingMode.title}",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextPrimary
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = ObsidianSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.BatteryChargingFull,
                            contentDescription = "Battery level",
                            tint = EmeraldReady,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${telemetry.batteryPercent}%",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextPrimary
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = ObsidianSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Wifi,
                            contentDescription = "Network status",
                            tint = if (telemetry.wifiConnected) CyberCyan else AmberThinking,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (telemetry.wifiConnected) "Wi-Fi" else "Net",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 2. SIGNATURE HASSEENA AI ORB CENTERPIECE
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            HasseenaOrb(
                orbState = orbState,
                orbConfig = orbConfig,
                audioLevel = audioLevel,
                onTapOrb = onTapOrb,
                onLongPressOrb = onLongPressOrb
            )
        }

        // 3. ORB STATE PILL & BARGE-IN INTERRUPT BUTTON
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val stateColor = when (orbState) {
                OrbState.IDLE -> CyberCyan
                OrbState.LISTENING -> EmeraldReady
                OrbState.THINKING -> AmberThinking
                OrbState.SPEAKING -> CyberCyan
                OrbState.EXECUTING -> QuantumViolet
                OrbState.ERROR -> CoralAlert
            }

            Surface(
                shape = RoundedCornerShape(50),
                color = stateColor.copy(alpha = 0.14f),
                border = androidx.compose.foundation.BorderStroke(1.dp, stateColor.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(stateColor)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${orbState.label} • ${orbState.statusSubtitle}",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextPrimary
                    )
                }
            }

            AnimatedVisibility(visible = orbState == OrbState.SPEAKING || orbState == OrbState.THINKING || isGenerating) {
                Button(
                    onClick = onInterrupt,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CoralAlert,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.testTag("interrupt_barge_in_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.StopCircle,
                        contentDescription = "Interrupt JARVIS",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Interrupt", style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        if (preferences.continuousConversation || preferences.wakeWordEnabled) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = buildString {
                    if (preferences.continuousConversation) append("Continuous Mode ON ")
                    if (preferences.wakeWordEnabled) append("• Wake Phrase: \"${preferences.wakePhrase}\"")
                },
                style = MaterialTheme.typography.labelSmall,
                color = EmeraldReady
            )
        }

        if (!voiceError.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = CoralAlert.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, CoralAlert.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = voiceError,
                    style = MaterialTheme.typography.bodyMedium,
                    color = CoralAlert,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 4. REAL-TIME STREAMING RESPONSE / VOICE TRANSCRIPT CARD
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = ObsidianSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("live_response_card")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = liveRouteBadge,
                        style = MaterialTheme.typography.labelMedium,
                        color = CyberCyan
                    )
                    if (lastLatencyMs > 0L) {
                        Text(
                            text = "${lastLatencyMs}ms",
                            style = MaterialTheme.typography.labelMedium,
                            color = EmeraldReady
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (partialTranscript.isNotBlank()) {
                    Text(
                        text = "“$partialTranscript…”",
                        style = MaterialTheme.typography.titleMedium,
                        color = EmeraldReady
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }

                Text(
                    text = liveHeadline,
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextPrimary,
                    maxLines = 8,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "View full history →",
                        style = MaterialTheme.typography.labelLarge,
                        color = CyberCyan,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onOpenChatStream() }
                            .padding(vertical = 4.dp, horizontal = 6.dp)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        IconButton(
                            onClick = { onSpeakResponse(liveHeadline) },
                            modifier = Modifier.testTag("speak_response_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Speak response aloud",
                                tint = TextSecondary
                            )
                        }
                        IconButton(
                            onClick = { onCopyResponse(liveHeadline) },
                            modifier = Modifier.testTag("copy_response_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy response text",
                                tint = TextSecondary
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 5. INSTANT HARDWARE CONTROL STRIP
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickHardwareTile(
                icon = if (isFlashlightOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                label = if (isFlashlightOn) "Torch ON" else "Torch OFF",
                active = isFlashlightOn,
                testTag = "quick_flashlight_toggle",
                onClick = onToggleFlashlight
            )
            QuickHardwareTile(
                icon = Icons.AutoMirrored.Filled.VolumeUp,
                label = "Vol + (${telemetry.musicVolumePercent}%)",
                active = false,
                testTag = "quick_volume_up",
                onClick = { onVolumeAdjust(true) }
            )
            QuickHardwareTile(
                icon = Icons.AutoMirrored.Filled.VolumeUp,
                label = "Vol -",
                active = false,
                testTag = "quick_volume_down",
                onClick = { onVolumeAdjust(false) }
            )
            QuickHardwareTile(
                icon = Icons.Default.Brightness6,
                label = "Bright 80%",
                active = false,
                testTag = "quick_brightness_high",
                onClick = { onBrightnessPreset(80) }
            )
            QuickHardwareTile(
                icon = Icons.Default.Brightness6,
                label = "Dim 25%",
                active = false,
                testTag = "quick_brightness_low",
                onClick = { onBrightnessPreset(25) }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 6. FAST LOCAL COMMAND ENGINE CHIPS
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "INSTANT ON-DEVICE & AI COMMANDS",
                style = MaterialTheme.typography.labelMedium,
                color = TextMuted
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                quickLocalCommands.forEach { cmd ->
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = ObsidianSurfaceElevated,
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable { onSubmitCommand(cmd) }
                    ) {
                        Text(
                            text = cmd,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 7. VOICE & TEXT COMMAND INPUT BAR
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = commandText,
                onValueChange = { commandText = it },
                placeholder = {
                    Text(
                        "Ask JARVIS or say 'Open YouTube'...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted
                    )
                },
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = BorderSubtle,
                    focusedContainerColor = ObsidianSurface,
                    unfocusedContainerColor = ObsidianSurface,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (commandText.isNotBlank()) {
                            onSubmitCommand(commandText)
                            commandText = ""
                        }
                    }
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("home_command_input")
            )

            IconButton(
                onClick = onTapOrb,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = if (orbState == OrbState.LISTENING) {
                                listOf(EmeraldReady, CyberCyan)
                            } else {
                                listOf(CyberCyan, QuantumViolet)
                            }
                        )
                    )
                    .testTag("home_voice_mic_button")
            ) {
                Icon(
                    imageVector = if (orbState == OrbState.LISTENING) Icons.Default.GraphicEq else Icons.Default.Mic,
                    contentDescription = "Tap to talk",
                    tint = Color.Black
                )
            }

            IconButton(
                onClick = {
                    if (commandText.isNotBlank()) {
                        onSubmitCommand(commandText)
                        commandText = ""
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(ObsidianSurfaceElevated)
                    .border(1.dp, BorderSubtle, CircleShape)
                    .testTag("home_send_command_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send command",
                    tint = CyberCyan
                )
            }
        }
    }
}

@Composable
private fun QuickHardwareTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (active) CyberCyan.copy(alpha = 0.2f) else ObsidianSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (active) CyberCyan else BorderSubtle
        ),
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (active) CyberCyan else TextSecondary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Medium,
                color = if (active) CyberCyan else TextPrimary
            )
        }
    }
}
