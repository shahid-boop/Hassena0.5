package com.example.services.cloud

import android.content.Context
import android.util.Log
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

enum class OperationType(val value: String) {
    CREATE("create"),
    UPDATE("update"),
    DELETE("delete"),
    LIST("list"),
    GET("get"),
    WRITE("write"),
}

fun handleFirestoreError(exception: Exception, operationType: OperationType, path: String?): String {
    val auth = FirebaseAuth.getInstance()
    val currentUser = auth.currentUser

    val providerInfoList = currentUser?.providerData?.map { provider ->
        JSONObject().apply {
            put("providerId", provider.providerId)
            put("email", provider.email)
        }
    } ?: emptyList()

    val authInfoJson = JSONObject().apply {
        put("userId", currentUser?.uid)
        put("email", currentUser?.email)
        put("emailVerified", currentUser?.isEmailVerified)
        put("tenantId", currentUser?.tenantId)
        put("providerInfo", JSONArray(providerInfoList))
    }

    val errorInfoJson = JSONObject().apply {
        put("error", exception.message ?: exception.toString())
        put("operationType", operationType.value)
        put("path", path)
        put("authInfo", authInfoJson)
    }

    val jsonString = errorInfoJson.toString()
    Log.e("FirestoreError", "Firestore Error: $jsonString")
    return jsonString
}

data class CloudMemoryFact(
    @DocumentId val id: String = "",
    val userId: String = "",
    val category: String = "FACT",
    val content: String = "",
    val source: String = "User",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

data class CloudChatMessage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val role: String = "user",
    val content: String = "",
    val providerName: String = "Direct Input",
    val modelName: String = "User",
    val routeCategory: String = "TEXT",
    val latencyMs: Long = 0L,
    val createdAt: Timestamp? = null
)

class CloudSyncRepository(private val db: FirebaseFirestore) {

    // CRITICAL: Always initialize with R.string.firestore_database_id
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth: FirebaseAuth
        get() = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeCloudMemories(): Flow<List<CloudMemoryFact>> = callbackFlow {
        val uid = auth.currentUser?.uid ?: "unauthenticated_probe"
        val path = "users/$uid/memories"
        val registration = db.collection("users")
            .document(uid)
            .collection("memories")
            .whereEqualTo("userId", uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    handleFirestoreError(error, OperationType.LIST, path)
                    close(error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val items = snapshot.toObjects(
                        CloudMemoryFact::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                    trySend(items)
                }
            }
        awaitClose { registration.remove() }
    }

    suspend fun createCloudMemory(
        category: String,
        content: String,
        source: String = "User"
    ): Result<String> {
        val uid = requireUserId()
        val normalizedCat = category.uppercase(Locale.US).let {
            if (it in setOf("PREFERENCE", "FACT", "INSTRUCTION", "HABIT")) it else "FACT"
        }
        val docId = "mem_${UUID.randomUUID().toString().replace("-", "")}"
        val docRef = db.collection("users")
            .document(uid)
            .collection("memories")
            .document(docId)

        val payload = mapOf(
            "userId" to uid,
            "category" to normalizedCat,
            "content" to content.trim().take(2000),
            "source" to source.trim().ifBlank { "User" }.take(120),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }

        return try {
            docRef.set(payload).await()
            Result.success(docId)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun getUserCloudMemories(): Result<List<CloudMemoryFact>> {
        val uid = requireUserId()
        val colRef = db.collection("users").document(uid).collection("memories")
        return try {
            val snapshot = colRef.whereEqualTo("userId", uid).get().await()
            val items = snapshot.toObjects(
                CloudMemoryFact::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
            Result.success(items)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, colRef.path)
            Result.failure(e)
        }
    }

    suspend fun getCloudMemoryById(ownerUid: String, memoryId: String): Result<CloudMemoryFact> {
        val docRef = db.collection("users")
            .document(ownerUid)
            .collection("memories")
            .document(memoryId)
        return try {
            val snapshot = docRef.get().await()
            val item = snapshot.toObject(
                CloudMemoryFact::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: throw NoSuchElementException("Memory document not found: $memoryId")
            Result.success(item)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteCloudMemory(memoryId: String): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users")
            .document(uid)
            .collection("memories")
            .document(memoryId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeCloudMessages(): Flow<List<CloudChatMessage>> = callbackFlow {
        val uid = auth.currentUser?.uid ?: "unauthenticated_probe"
        val path = "users/$uid/messages"
        val registration = db.collection("users")
            .document(uid)
            .collection("messages")
            .whereEqualTo("userId", uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    handleFirestoreError(error, OperationType.LIST, path)
                    close(error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val items = snapshot.toObjects(
                        CloudChatMessage::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedBy { it.createdAt ?: Timestamp(0, 0) }
                    trySend(items)
                }
            }
        awaitClose { registration.remove() }
    }

    suspend fun createCloudMessage(
        role: String,
        content: String,
        providerName: String,
        modelName: String,
        routeCategory: String,
        latencyMs: Long
    ): Result<String> {
        val uid = requireUserId()
        val safeRole = if (role in setOf("user", "assistant", "tool")) role else "assistant"
        val safeContent = content.trim().ifBlank { "…" }.take(8000)
        val docId = "msg_${UUID.randomUUID().toString().replace("-", "")}"
        val docRef = db.collection("users")
            .document(uid)
            .collection("messages")
            .document(docId)

        val payload = mapOf(
            "userId" to uid,
            "role" to safeRole,
            "content" to safeContent,
            "providerName" to providerName.ifBlank { "JARVIS AI Assistant"}.take(120),
            "modelName" to modelName.ifBlank { "Default" }.take(120),
            "routeCategory" to routeCategory.ifBlank { "TEXT" }.take(120),
            "latencyMs" to latencyMs.coerceIn(0L, 600000L),
            "createdAt" to FieldValue.serverTimestamp()
        ).filterValues { it != null }

        return try {
            docRef.set(payload).await()
            Result.success(docId)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }
}
