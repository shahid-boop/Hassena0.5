package com.example

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TravelExplore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.providers.HasseenaDestination
import com.example.providers.HasseenaViewModel
import com.example.services.android.AndroidControlService
import com.example.ui.features.auth.HasseenaAuthScreen
import com.example.ui.features.chat.ChatStreamScreen
import com.example.ui.features.connectors.ControlAndPermissionCenterScreen
import com.example.ui.features.home.HomeVoiceScreen
import com.example.ui.features.research.ResearchScreen
import com.example.ui.features.settings.SettingsAndMemoryScreen
import com.example.ui.features.visual_lens.VisualLensScreen
import com.example.ui.features.workspace.FileWorkspaceScreen
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.HasseenaTheme
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HasseenaTheme {
                var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

                DisposableEffect(Unit) {
                    val listener = FirebaseAuth.AuthStateListener { auth ->
                        currentUser = auth.currentUser
                    }
                    Firebase.auth.addAuthStateListener(listener)
                    onDispose {
                        Firebase.auth.removeAuthStateListener(listener)
                    }
                }

                if (currentUser == null) {
                    HasseenaAuthScreen(
                        onAuthSuccess = {
                            currentUser = Firebase.auth.currentUser
                        }
                    )
                } else {
                    val hasseenaViewModel: HasseenaViewModel = viewModel(key = currentUser?.uid ?: "authenticated")
                    val windowBrightness by hasseenaViewModel.androidControlService.requestedAppWindowBrightness
                        .collectAsStateWithLifecycle()

                    LaunchedEffect(windowBrightness) {
                        val target = windowBrightness
                        if (target != null) {
                            val params = window.attributes
                            params.screenBrightness = target.coerceIn(0.05f, 1.0f)
                            window.attributes = params
                        }
                    }

                    HasseenaAssistantApp(
                        currentUser = currentUser,
                        viewModel = hasseenaViewModel,
                        onSignOutComplete = {
                            currentUser = null
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun HasseenaAssistantApp(
    currentUser: FirebaseUser?,
    viewModel: HasseenaViewModel,
    onSignOutComplete: () -> Unit = {}
) {
    val currentDest by viewModel.currentDestination.collectAsStateWithLifecycle()
    val preferences by viewModel.userPreferences.collectAsStateWithLifecycle()
    val orbState by viewModel.orbState.collectAsStateWithLifecycle()
    val audioLevel by viewModel.audioLevel.collectAsStateWithLifecycle()
    val partialTranscript by viewModel.partialVoiceTranscript.collectAsStateWithLifecycle()
    val voiceError by viewModel.voiceError.collectAsStateWithLifecycle()
    val liveHeadline by viewModel.liveResponseHeadline.collectAsStateWithLifecycle()
    val liveRouteBadge by viewModel.liveRouteBadge.collectAsStateWithLifecycle()
    val lastLatencyMs by viewModel.lastLatencyMs.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val isFlashlightOn by viewModel.isFlashlightOn.collectAsStateWithLifecycle()
    val telemetry by viewModel.deviceTelemetry.collectAsStateWithLifecycle()
    val permissions by viewModel.permissionsList.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val activeNotifications by viewModel.activeNotifications.collectAsStateWithLifecycle()
    val isAccessibilityActive by viewModel.isAccessibilityActive.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val memoryFacts by viewModel.memoryFacts.collectAsStateWithLifecycle()
    val cloudMemories by viewModel.cloudMemories.collectAsStateWithLifecycle()
    val cloudSyncStatus by viewModel.cloudSyncStatus.collectAsStateWithLifecycle()
    val cacheCount by viewModel.cacheCount.collectAsStateWithLifecycle()
    val pendingConfirmation by viewModel.pendingConfirmation.collectAsStateWithLifecycle()

    // Visual Lens states
    val capturedBitmap by viewModel.capturedLensBitmap.collectAsStateWithLifecycle()
    val lensAnalysisText by viewModel.lensAnalysisText.collectAsStateWithLifecycle()
    val isLensAnalyzing by viewModel.isLensAnalyzing.collectAsStateWithLifecycle()

    // Research states
    val researchMode by viewModel.researchMode.collectAsStateWithLifecycle()
    val researchStatus by viewModel.researchStatus.collectAsStateWithLifecycle()
    val researchSummary by viewModel.researchSummary.collectAsStateWithLifecycle()
    val researchSources by viewModel.researchSources.collectAsStateWithLifecycle()
    val isResearching by viewModel.isResearching.collectAsStateWithLifecycle()

    // Refresh permissions when returning from Android Settings
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshTelemetryAndPermissions()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Contextual Microphone permission launcher (activated only when user taps Orb/Mic)
    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.refreshTelemetryAndPermissions()
        if (granted) {
            viewModel.voiceService.startListening(bargeInAllowed = preferences.bargeInEnabled)
        }
    }

    // Contextual runtime permission launcher for Permission Center
    val genericPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        viewModel.refreshTelemetryAndPermissions()
    }

    // Sensitive Action Confirmation Dialog ("Call this number?", "Send this message?", "Delete memory?")
    val confirmation = pendingConfirmation
    if (confirmation != null) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissPendingConfirmation() },
            containerColor = ObsidianSurfaceElevated,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary,
            title = {
                Text(text = confirmation.title)
            },
            text = {
                Text(text = confirmation.description)
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.confirmPendingAction() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberCyan,
                        contentColor = Color.Black
                    ),
                    modifier = Modifier.testTag("confirm_sensitive_action_button")
                ) {
                    Text(confirmation.confirmButtonText)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { viewModel.dismissPendingConfirmation() },
                    modifier = Modifier.testTag("cancel_sensitive_action_button")
                ) {
                    Text("Cancel", color = CoralAlert)
                }
            }
        )
    }

    val navItems = listOf(
        Triple(HasseenaDestination.HOME, "Voice", Icons.Default.GraphicEq),
        Triple(HasseenaDestination.CHAT, "Stream", Icons.AutoMirrored.Filled.Chat),
        Triple(HasseenaDestination.VISUAL_LENS, "Lens", Icons.Default.CenterFocusStrong),
        Triple(HasseenaDestination.RESEARCH, "Research", Icons.Default.TravelExplore),
        Triple(HasseenaDestination.CONTROL_CENTER, "Control", Icons.Default.Security),
        Triple(HasseenaDestination.FILE_WORKSPACE, "Files", Icons.Default.FolderOpen),
        Triple(HasseenaDestination.SETTINGS, "Settings", Icons.Default.Settings)
    )

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF050711), Color(0xFF0A1022), Color(0xFF070A14))))
    ) {
        Hasseena3DBackdrop(modifier = Modifier.fillMaxSize())
        val isExpandedScreen = maxWidth >= 640.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            bottomBar = {
                if (!isExpandedScreen) {
                    HasseenaBottomNavigationBar(
                        currentDestination = currentDest,
                        items = navItems,
                        onSelect = { viewModel.navigateTo(it) }
                    )
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isExpandedScreen) {
                    HasseenaSideNavigationRail(
                        currentDestination = currentDest,
                        items = navItems,
                        onSelect = { viewModel.navigateTo(it) }
                    )
                }

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    when (currentDest) {
                        HasseenaDestination.HOME -> HomeVoiceScreen(
                            orbState = orbState,
                            orbConfig = preferences.orbConfig,
                            audioLevel = audioLevel,
                            partialTranscript = partialTranscript,
                            voiceError = voiceError,
                            liveHeadline = liveHeadline,
                            liveRouteBadge = liveRouteBadge,
                            lastLatencyMs = lastLatencyMs,
                            isGenerating = isGenerating,
                            isFlashlightOn = isFlashlightOn,
                            telemetry = telemetry,
                            preferences = preferences,
                            onTapOrb = {
                                viewModel.onOrbTapped(
                                    onRequestMicPermission = {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                )
                            },
                            onLongPressOrb = { viewModel.onOrbLongPressed() },
                            onInterrupt = { viewModel.interruptEverything() },
                            onSubmitCommand = { cmd -> viewModel.submitCommandOrPrompt(cmd) },
                            onToggleFlashlight = {
                                val next = !isFlashlightOn
                                viewModel.submitCommandOrPrompt(
                                    if (next) "Turn on flashlight" else "Turn off flashlight"
                                )
                            },
                            onVolumeAdjust = { up ->
                                viewModel.submitCommandOrPrompt(
                                    if (up) "Increase volume" else "Decrease volume"
                                )
                            },
                            onBrightnessPreset = { pct ->
                                viewModel.submitCommandOrPrompt("Set brightness to $pct")
                            },
                            onCopyResponse = { text ->
                                viewModel.androidControlService.copyToClipboard("JARVIS Response", text)
                            },
                            onSpeakResponse = { text ->
                                viewModel.voiceService.speakImmediate(text)
                            },
                            onOpenChatStream = {
                                viewModel.navigateTo(HasseenaDestination.CHAT)
                            }
                        )

                        HasseenaDestination.CHAT -> ChatStreamScreen(
                            messages = messages,
                            isGenerating = isGenerating,
                            onSendPrompt = { prompt -> viewModel.submitCommandOrPrompt(prompt) },
                            onVoiceMicTap = {
                                viewModel.onOrbTapped(
                                    onRequestMicPermission = {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                )
                            },
                            onInterrupt = { viewModel.interruptEverything() },
                            onSpeakMessage = { text -> viewModel.voiceService.speakImmediate(text) },
                            onCopyMessage = { text ->
                                viewModel.androidControlService.copyToClipboard("JARVIS Message", text)
                            },
                            onShareMessage = { text ->
                                viewModel.androidControlService.shareTextContent(text)
                            },
                            onClearHistory = { viewModel.clearAllConversations() },
                            onNavigateBackHome = { viewModel.navigateTo(HasseenaDestination.HOME) }
                        )

                        HasseenaDestination.VISUAL_LENS -> VisualLensScreen(
                            capturedBitmap = capturedBitmap,
                            analysisText = lensAnalysisText,
                            isAnalyzing = isLensAnalyzing,
                            onBitmapCaptured = { bmp -> viewModel.setLensBitmap(bmp) },
                            onAnalyzePrompt = { prompt -> viewModel.analyzeVisualLensImage(prompt) },
                            onAnalyzeActiveScreen = { viewModel.analyzeActiveScreenWithAccessibility() },
                            onSpeakText = { text -> viewModel.voiceService.speakImmediate(text) },
                            onNavigateBackHome = { viewModel.navigateTo(HasseenaDestination.HOME) }
                        )

                        HasseenaDestination.RESEARCH -> ResearchScreen(
                            selectedMode = researchMode,
                            isResearching = isResearching,
                            researchStatus = researchStatus,
                            researchSummary = researchSummary,
                            researchSources = researchSources,
                            onSelectMode = { mode -> viewModel.setResearchMode(mode) },
                            onExecuteResearch = { query -> viewModel.runWebResearch(query) },
                            onOpenSourceUrl = { url -> viewModel.appLauncherService.openUrl(url) },
                            onSpeakSummary = { text -> viewModel.voiceService.speakImmediate(text) },
                            onNavigateBackHome = { viewModel.navigateTo(HasseenaDestination.HOME) }
                        )

                        HasseenaDestination.CONTROL_CENTER -> ControlAndPermissionCenterScreen(
                            telemetry = telemetry,
                            permissions = permissions,
                            installedApps = installedApps,
                            activeNotifications = activeNotifications,
                            isAccessibilityActive = isAccessibilityActive,
                            isFlashlightOn = isFlashlightOn,
                            onRefreshStatus = { viewModel.refreshTelemetryAndPermissions() },
                            onRequestRuntimePermission = { perm ->
                                genericPermissionLauncher.launch(perm)
                            },
                            onOpenSpecialSettings = { action, pkgSpecific ->
                                viewModel.androidControlService.openSystemSettingsScreen(action, pkgSpecific)
                            },
                            onToggleFlashlight = { enable ->
                                viewModel.androidControlService.setFlashlight(enable)
                                viewModel.refreshTelemetryAndPermissions()
                            },
                            onSetVolumePercent = { pct ->
                                viewModel.androidControlService.adjustVolume(
                                    AndroidControlService.VolumeDirection.SET_PERCENT,
                                    pct
                                )
                                viewModel.refreshTelemetryAndPermissions()
                            },
                            onSetBrightnessPercent = { pct ->
                                viewModel.androidControlService.setScreenBrightnessPercent(pct)
                                viewModel.refreshTelemetryAndPermissions()
                            },
                            onMediaKey = { code, label ->
                                viewModel.androidControlService.sendMediaKey(code, label)
                            },
                            onOpenWifiPanel = { viewModel.androidControlService.openWifiControlPanel() },
                            onOpenBluetoothSettings = {
                                viewModel.androidControlService.openSystemSettingsScreen(
                                    android.provider.Settings.ACTION_BLUETOOTH_SETTINGS
                                )
                            },
                            onSetTimerSeconds = { secs -> viewModel.androidControlService.setTimer(secs) },
                            onSetAlarm = { hr, min -> viewModel.androidControlService.setAlarm(hr, min) },
                            onCreateCalendarEvent = { title ->
                                viewModel.androidControlService.createCalendarEvent(title)
                            },
                            onSubmitCommandWithConfirmation = { cmd ->
                                viewModel.submitCommandOrPrompt(cmd)
                            },
                            onLaunchInstalledApp = { app ->
                                viewModel.appLauncherService.launchPackageDirectly(app.packageName, app.appName)
                            },
                            onAccessibilityCommand = { cmd ->
                                viewModel.submitCommandOrPrompt(cmd)
                            },
                            onNavigateBackHome = { viewModel.navigateTo(HasseenaDestination.HOME) }
                        )

                        HasseenaDestination.FILE_WORKSPACE -> FileWorkspaceScreen(viewModel)

                        HasseenaDestination.SETTINGS -> SettingsAndMemoryScreen(
                            currentUser = currentUser,
                            preferences = preferences,
                            memoryFacts = memoryFacts,
                            cloudMemoryCount = cloudMemories.size,
                            cloudSyncStatus = cloudSyncStatus,
                            cacheCount = cacheCount,
                            isProviderKeyConfigured = { provider ->
                                viewModel.aiService.isProviderKeyAvailable(provider)
                            },
                            onSelectRoutingMode = { mode -> viewModel.updateRoutingMode(mode) },
                            onSelectProviderAndModel = { provider, modelId ->
                                viewModel.updateProviderAndModel(provider, modelId)
                            },
                            onSelectPersonality = { persona -> viewModel.updatePersonality(persona) },
                            onToggleMemory = { enabled -> viewModel.updateMemoryEnabled(enabled) },
                            onToggleCache = { enabled -> viewModel.updateCacheEnabled(enabled) },
                            onUpdateCustomInstructions = { instr ->
                                viewModel.updateCustomInstructions(instr)
                            },
                            onAddMemoryFact = { cat, content -> viewModel.addMemoryFact(cat, content) },
                            onDeleteMemoryFact = { id -> viewModel.deleteMemoryFact(id) },
                            onRequestDeleteAllMemory = { viewModel.requestClearMemoryConfirmation() },
                            onClearConversations = { viewModel.clearAllConversations() },
                            onSyncLocalToCloud = { viewModel.syncLocalMemoriesToCloud() },
                            onSignOutComplete = onSignOutComplete,
                            onUpdateOrbConfig = { cfg -> viewModel.updateOrbConfig(cfg) },
                            onUpdateWakeWord = { enabled, phrase ->
                                viewModel.updateWakeWordConfig(enabled, phrase)
                            },
                            onUpdateVoicePrefs = { cont, tts, barge, hapt ->
                                viewModel.updateVoicePreferences(cont, tts, barge, hapt)
                            },
                            onNavigateBackHome = { viewModel.navigateTo(HasseenaDestination.HOME) },
                            onSaveApiKey = { provider, key ->
                                runCatching {
                                    viewModel.apiKeyStore.save(provider, key)
                                }.onFailure { error ->
                                    android.util.Log.e("ApiKeyManager", "Could not save API key", error)
                                }
                            },
                            onRemoveApiKey = { provider ->
                                runCatching {
                                    viewModel.apiKeyStore.remove(provider)
                                }.onFailure { error ->
                                    android.util.Log.e("ApiKeyManager", "Could not remove API key", error)
                                }
                              },
                            onTestApiKey = { provider, key, onResult ->
                                viewModel.testApiKey(provider, key, onResult)
                            },
                            onSaveVoiceApiKey = { key -> viewModel.voiceApiKeyStore.saveApiKey(key) },
                            onSaveVoiceId = { id -> viewModel.voiceApiKeyStore.saveVoiceId("hasseena_custom", id) },
                            currentVoicePack = viewModel.voiceApiKeyStore.getSelectedVoicePack(),
                            onSaveVoiceIdForPack = { packId, id -> viewModel.voiceApiKeyStore.saveVoiceId(packId, id) },
                            onSelectVoicePack = { packId -> viewModel.voiceApiKeyStore.saveSelectedVoicePack(packId) },
                            onGetVoiceIdForPack = { packId -> viewModel.voiceApiKeyStore.getVoiceId(packId) },
                            onTestElevenLabsVoice = { voiceId, onResult -> viewModel.testElevenLabsVoice(voiceId, onResult) }
                        )
                    }
                }
            }
        }
    }
}

/** Shared ambient sci-fi backdrop used behind every authenticated destination. */
@Composable
private fun Hasseena3DBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        // Soft cyan/violet volumetric glows.
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x3320DFFF), Color.Transparent),
                center = Offset(w * 0.12f, h * 0.18f),
                radius = w * 0.58f
            ), radius = w * 0.58f, center = Offset(w * 0.12f, h * 0.18f)
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x2D8B5CFF), Color.Transparent),
                center = Offset(w * 0.94f, h * 0.68f),
                radius = w * 0.62f
            ), radius = w * 0.62f, center = Offset(w * 0.94f, h * 0.68f)
        )
        // Fine perspective grid, intentionally subtle so content remains readable.
        val gridColor = Color(0x1429C8EF)
        val gap = 34.dp.toPx()
        var x = 0f
        while (x <= w) {
            drawLine(gridColor, Offset(x, h * 0.60f), Offset(x, h), strokeWidth = 0.7.dp.toPx())
            x += gap
        }
        var y = h * 0.62f
        while (y <= h) {
            drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 0.7.dp.toPx())
            y += gap
        }
        // Holographic orbit rings in the upper field.
        val center = Offset(w * 0.83f, h * 0.13f)
        listOf(54f, 72f, 91f).forEachIndexed { index, radiusDp ->
            drawCircle(
                color = if (index == 1) Color(0x2445DDF5) else Color(0x1B9C76FF),
                radius = radiusDp.dp.toPx(),
                center = center,
                style = Stroke(width = if (index == 1) 1.2.dp.toPx() else 0.7.dp.toPx())
            )
        }
        drawCircle(Color(0x6685F3FF), radius = 2.2.dp.toPx(), center = center)
    }
}

@Composable
private fun HasseenaBottomNavigationBar(
    currentDestination: HasseenaDestination,
    items: List<Triple<HasseenaDestination, String, ImageVector>>,
    onSelect: (HasseenaDestination) -> Unit
) {
    NavigationBar(
        modifier = Modifier
            .padding(horizontal = 10.dp, vertical = 7.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.verticalGradient(listOf(Color(0xEE18243D), Color(0xF5091020))))
            .border(1.dp, Color(0x8846DDFB), RoundedCornerShape(24.dp)),
        containerColor = Color.Transparent,
        contentColor = TextPrimary,
        tonalElevation = 0.dp
    ) {
        items.forEach { (dest, label, icon) ->
            val selected = currentDestination == dest
            NavigationBarItem(
                selected = selected,
                onClick = { onSelect(dest) },
                icon = {
                    // Raised holographic icon tile; preserves the original Material icon semantics.
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .shadow(
                                elevation = if (selected) 12.dp else 5.dp,
                                shape = RoundedCornerShape(14.dp),
                                ambientColor = if (selected) CyberCyan else Color(0xFF415B88),
                                spotColor = if (selected) CyberCyan else Color(0xFF415B88)
                            )
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(
                                    if (selected) listOf(Color(0xFF9AF7FF), Color(0xFF37BDEB), Color(0xFF6158D9))
                                    else listOf(Color(0xFF263954), Color(0xFF111C31), Color(0xFF202A47))
                                )
                            )
                            .border(
                                width = if (selected) 1.4.dp else 0.8.dp,
                                color = if (selected) Color(0xFFD2FCFF) else Color(0x664BDCF5),
                                shape = RoundedCornerShape(14.dp)
                            ),
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = if (selected) Color(0xFF071525) else Color(0xFF9CEBFA),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                },
                label = {
                    Text(text = label)
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.Black,
                    selectedTextColor = CyberCyan,
                    indicatorColor = CyberCyan,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary
                ),
                modifier = Modifier.testTag("nav_${dest.route}")
            )
        }
    }
}

@Composable
private fun HasseenaSideNavigationRail(
    currentDestination: HasseenaDestination,
    items: List<Triple<HasseenaDestination, String, ImageVector>>,
    onSelect: (HasseenaDestination) -> Unit
) {
    NavigationRail(
        containerColor = ObsidianSurface,
        contentColor = TextPrimary
    ) {
        items.forEach { (dest, label, icon) ->
            val selected = currentDestination == dest
            NavigationRailItem(
                selected = selected,
                onClick = { onSelect(dest) },
                icon = {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .shadow(
                                elevation = if (selected) 12.dp else 5.dp,
                                shape = RoundedCornerShape(15.dp),
                                ambientColor = if (selected) CyberCyan else Color(0xFF415B88),
                                spotColor = if (selected) CyberCyan else Color(0xFF415B88)
                            )
                            .clip(RoundedCornerShape(15.dp))
                            .background(
                                Brush.linearGradient(
                                    if (selected) listOf(Color(0xFF9AF7FF), Color(0xFF37BDEB), Color(0xFF6158D9))
                                    else listOf(Color(0xFF263954), Color(0xFF111C31), Color(0xFF202A47))
                                )
                            )
                            .border(
                                width = if (selected) 1.4.dp else 0.8.dp,
                                color = if (selected) Color(0xFFD2FCFF) else Color(0x664BDCF5),
                                shape = RoundedCornerShape(15.dp)
                            ),
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = if (selected) Color(0xFF071525) else Color(0xFF9CEBFA),
                            modifier = Modifier.size(23.dp)
                        )
                    }
                },
                label = {
                    Text(text = label)
                },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = Color.Black,
                    selectedTextColor = CyberCyan,
                    indicatorColor = CyberCyan,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary
                ),
                modifier = Modifier.testTag("rail_${dest.route}")
            )
        }
    }
}
