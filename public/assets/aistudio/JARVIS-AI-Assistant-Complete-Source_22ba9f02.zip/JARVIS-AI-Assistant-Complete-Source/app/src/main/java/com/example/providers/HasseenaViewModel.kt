package com.example.providers

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.models.AIProviderType
import com.example.models.AssistantPersonality
import com.example.models.CapturedNotification
import com.example.models.DeviceTelemetrySnapshot
import com.example.models.InstalledAppInfo
import com.example.models.OrbConfig
import com.example.models.OrbState
import com.example.models.PendingConfirmationAction
import com.example.models.PermissionStatusItem
import com.example.models.ResearchMode
import com.example.models.ResearchSource
import com.example.models.RoutingMode
import com.example.models.TaskCategory
import com.example.services.accessibility.HasseenaAccessibilityService
import com.example.services.ai.AIModelRouter
import com.example.services.ai.AIService
import com.example.services.ai.ApiKeyStore
import com.example.services.ai.LocalCommandClassifier
import com.example.services.android.AndroidControlService
import com.example.services.android.AppLauncherService
import com.example.services.cloud.CloudMemoryFact
import com.example.services.cloud.CloudSyncRepository
import com.example.services.memory.ChatMessageEntity
import com.example.services.memory.HasseenaDatabase
import com.example.services.memory.HasseenaUserPreferences
import com.example.services.memory.MemoryFactEntity
import com.example.services.memory.MemoryRepository
import com.example.services.memory.PreferencesRepository
import com.example.services.notifications.HasseenaNotificationListenerService
import com.example.services.search.WebResearchService
import com.example.services.voice.VoiceAssistantService
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class HasseenaDestination(val route: String, val label: String) {
    HOME("home", "Assistant"),
    CHAT("chat", "Stream"),
    VISUAL_LENS("visual_lens", "Lens"),
    RESEARCH("research", "Research"),
    CONTROL_CENTER("control_center", "Control"),
    FILE_WORKSPACE("file_workspace", "Files"),
    SETTINGS("settings", "Settings")
}

class HasseenaViewModel(application: Application) : AndroidViewModel(application) {

    private val database = HasseenaDatabase.getInstance(application)
    val memoryRepository = MemoryRepository(database.hasseenaDao())
    val preferencesRepository = PreferencesRepository(application)
    val cloudSyncRepository = CloudSyncRepository(application)

    val appLauncherService = AppLauncherService(application)
    val androidControlService = AndroidControlService(application, appLauncherService)
    val localCommandClassifier = LocalCommandClassifier(application, androidControlService)
    val apiKeyStore = ApiKeyStore(application)
    val aiService = AIService(androidControlService, apiKeyStore)
    val aiModelRouter = AIModelRouter()
    val webResearchService = WebResearchService(aiService)
    val voiceService = VoiceAssistantService(application)
    val voiceApiKeyStore = voiceService.voiceApiKeyStore

    fun testElevenLabsVoice(voiceId: String, onResult: (Boolean, String) -> Unit) {
        voiceService.testElevenLabsVoice(voiceId, onResult)
    }

    // Navigation state
    private val _currentDestination = MutableStateFlow(HasseenaDestination.HOME)
    val currentDestination: StateFlow<HasseenaDestination> = _currentDestination.asStateFlow()

    // Reactive streams from repositories
    val userPreferences: StateFlow<HasseenaUserPreferences> = preferencesRepository.preferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = HasseenaUserPreferences()
        )

    val messages: StateFlow<List<ChatMessageEntity>> = memoryRepository.messagesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val memoryFacts: StateFlow<List<MemoryFactEntity>> = memoryRepository.memoryFactsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val cacheCount: StateFlow<Int> = memoryRepository.cacheCountFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    val cloudMemories: StateFlow<List<CloudMemoryFact>> = cloudSyncRepository.observeCloudMemories()
        .catch { emit(emptyList()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _cloudSyncStatus = MutableStateFlow<String?>(null)
    val cloudSyncStatus: StateFlow<String?> = _cloudSyncStatus.asStateFlow()

    // Live Orb & Pipeline states
    private val _internalOrbState = MutableStateFlow(OrbState.IDLE)
    val orbState: StateFlow<OrbState> = combine(
        _internalOrbState,
        voiceService.isListening,
        voiceService.isSpeaking
    ) { internal, listening, speaking ->
        when {
            listening -> OrbState.LISTENING
            internal == OrbState.THINKING || internal == OrbState.EXECUTING || internal == OrbState.ERROR -> internal
            speaking -> OrbState.SPEAKING
            else -> OrbState.IDLE
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = OrbState.IDLE
    )

    val audioLevel: StateFlow<Float> = voiceService.audioLevel
    val partialVoiceTranscript: StateFlow<String> = voiceService.partialTranscript
    val voiceError: StateFlow<String?> = voiceService.voiceError

    // Live streaming text shown on Home & Chat screens without waiting for full response
    private val _liveResponseHeadline = MutableStateFlow("Ready. Tap the orb or speak a command.")
    val liveResponseHeadline: StateFlow<String> = _liveResponseHeadline.asStateFlow()

    private val _liveRouteBadge = MutableStateFlow("FAST PIPELINE READY")
    val liveRouteBadge: StateFlow<String> = _liveRouteBadge.asStateFlow()

    private val _lastLatencyMs = MutableStateFlow(0L)
    val lastLatencyMs: StateFlow<Long> = _lastLatencyMs.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    // Sensitive action confirmation modal state
    private val _pendingConfirmation = MutableStateFlow<PendingConfirmationAction?>(null)
    val pendingConfirmation: StateFlow<PendingConfirmationAction?> = _pendingConfirmation.asStateFlow()

    // Telemetry, Permissions & Installed Apps
    private val _deviceTelemetry = MutableStateFlow(androidControlService.getDeviceTelemetry())
    val deviceTelemetry: StateFlow<DeviceTelemetrySnapshot> = _deviceTelemetry.asStateFlow()

    private val _permissionsList = MutableStateFlow(androidControlService.getPermissionsStatusList())
    val permissionsList: StateFlow<List<PermissionStatusItem>> = _permissionsList.asStateFlow()

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    val isFlashlightOn: StateFlow<Boolean> = androidControlService.isFlashlightOn
    val activeNotifications: StateFlow<List<CapturedNotification>> = HasseenaNotificationListenerService.notifications
    val isAccessibilityActive: StateFlow<Boolean> = HasseenaAccessibilityService.isRunning

    // Visual Lens State
    private val _capturedLensBitmap = MutableStateFlow<Bitmap?>(null)
    val capturedLensBitmap: StateFlow<Bitmap?> = _capturedLensBitmap.asStateFlow()

    private val _lensAnalysisText = MutableStateFlow("")
    val lensAnalysisText: StateFlow<String> = _lensAnalysisText.asStateFlow()

    private val _isLensAnalyzing = MutableStateFlow(false)
    val isLensAnalyzing: StateFlow<Boolean> = _isLensAnalyzing.asStateFlow()

    // Web & Deep Research State
    private val _researchMode = MutableStateFlow(ResearchMode.FAST_SEARCH)
    val researchMode: StateFlow<ResearchMode> = _researchMode.asStateFlow()

    private val _researchStatus = MutableStateFlow("")
    val researchStatus: StateFlow<String> = _researchStatus.asStateFlow()

    private val _researchSummary = MutableStateFlow("")
    val researchSummary: StateFlow<String> = _researchSummary.asStateFlow()

    private val _researchSources = MutableStateFlow<List<ResearchSource>>(emptyList())
    val researchSources: StateFlow<List<ResearchSource>> = _researchSources.asStateFlow()

    private val _isResearching = MutableStateFlow(false)
    val isResearching: StateFlow<Boolean> = _isResearching.asStateFlow()

    private var activeGenerationJob: Job? = null

    init {
        voiceService.onFinalTranscript = { spokenText ->
            onVoiceCommandCaptured(spokenText)
        }
        voiceService.onBargeInTriggered = {
            cancelActiveGeneration()
        }
        voiceService.onTtsCompletedAllChunks = {
            val prefs = userPreferences.value
            if (prefs.continuousConversation && !_isGenerating.value) {
                voiceService.startListening(bargeInAllowed = true)
            }
        }

        viewModelScope.launch {
            _installedApps.value = appLauncherService.refreshInstalledApps()
            refreshTelemetryAndPermissions()
        }
    }

    fun navigateTo(destination: HasseenaDestination) {
        _currentDestination.value = destination
        refreshTelemetryAndPermissions()
    }

    fun refreshTelemetryAndPermissions() {
        _deviceTelemetry.value = androidControlService.getDeviceTelemetry()
        _permissionsList.value = androidControlService.getPermissionsStatusList()
    }

    // =========================================================================
    // ORB & BARGE-IN INTERACTION
    // =========================================================================
    fun onOrbTapped(onRequestMicPermission: () -> Unit) {
        val prefs = userPreferences.value
        if ( prefs.hapticFeedbackEnabled) {
            androidControlService.triggerHapticPulse(25L)
        }

        if (!voiceService.hasMicrophonePermission()) {
            onRequestMicPermission()
            return
        }

        // Barge-In: If Hasseena is currently speaking or thinking, stop immediately and listen!
        if (voiceService.isSpeaking.value || _isGenerating.value) {
            cancelActiveGeneration()
            voiceService.stopSpeakingImmediately()
            voiceService.startListening(bargeInAllowed = true)
            return
        }

        if (voiceService.isListening.value) {
            voiceService.stopListening()
        } else {
            voiceService.startListening(bargeInAllowed = prefs.bargeInEnabled)
        }
    }

    fun onOrbLongPressed() {
        viewModelScope.launch {
            val prefs = userPreferences.value
            val newContinuous = !prefs.continuousConversation
            preferencesRepository.setVoiceSettings(
                continuousConversation = newContinuous,
                autoSpeakTts = prefs.autoSpeakTts,
                bargeInEnabled = prefs.bargeInEnabled,
                hapticFeedbackEnabled = prefs.hapticFeedbackEnabled
            )
            androidControlService.triggerHapticPulse(60L)
            val msg = if (newContinuous) "Continuous voice conversation enabled." else "Continuous voice conversation disabled."
            _liveResponseHeadline.value = msg
            if (prefs.autoSpeakTts) {
                voiceService.speakImmediate(msg)
            }
        }
    }

    fun interruptEverything() {
        cancelActiveGeneration()
        voiceService.stopSpeakingImmediately()
        voiceService.stopListening()
        _internalOrbState.value = OrbState.IDLE
        _liveRouteBadge.value = "INTERRUPTED • READY"
    }

    private fun cancelActiveGeneration() {
        activeGenerationJob?.cancel()
        activeGenerationJob = null
        _isGenerating.value = false
        _isLensAnalyzing.value = false
        _isResearching.value = false
        _internalOrbState.value = OrbState.IDLE
    }

    private fun onVoiceCommandCaptured(transcript: String) {
        val prefs = userPreferences.value
        val cleaned = transcript.trim()
        if (cleaned.isEmpty()) return

        // If wake-word mode is enabled, allow either wake-phrase prefix or direct tap-to-talk
        val strippedCommand = if (prefs.wakeWordEnabled) {
            val wakeLower = prefs.wakePhrase.lowercase()
            if (cleaned.lowercase().startsWith(wakeLower)) {
                cleaned.substring(wakeLower.length).trim().ifBlank { "Hello JARVIS" }
            } else {
                cleaned
            }
        } else {
            cleaned
        }

        submitCommandOrPrompt(strippedCommand, fromVoice = true)
    }

    // =========================================================================
    // FAST PIPELINE: LOCAL COMMAND -> CACHE -> SMART AI ROUTER -> STREAM + TTS
    // =========================================================================
    fun submitCommandOrPrompt(rawInput: String, fromVoice: Boolean = false) {
        val query = rawInput.trim()
        if (query.isEmpty()) return

        // Cancel any previous generation & stop previous speech immediately
        cancelActiveGeneration()
        voiceService.stopSpeakingImmediately()

        activeGenerationJob = viewModelScope.launch {
            val prefs = preferencesRepository.preferencesFlow.first()

            // Save user message immediately
            memoryRepository.addMessage(
                ChatMessageEntity(
                    role = "user",
                    content = query,
                    providerName = if (fromVoice) "Voice STT" else "Direct Input",
                    modelName = "User",
                    routeCategory = if (fromVoice) "VOICE" else "TEXT"
                )
            )

            // Check implicit memory extraction ("Remember that...", "My name is...")
            val savedFact = memoryRepository.extractAndSaveImplicitMemoryIfApplicable(
                userText = query,
                memoryEnabled = prefs.memoryEnabled
            )
            if (savedFact != null && Firebase.auth.currentUser != null) {
                viewModelScope.launch {
                    cloudSyncRepository.createCloudMemory("FACT", savedFact, "Voice/Chat Command")
                }
            }

            // -----------------------------------------------------------------
            // STAGE 1: FAST LOCAL COMMAND ENGINE (<5ms, zero cloud latency)
            // -----------------------------------------------------------------
            val localResult = localCommandClassifier.tryExecuteLocalCommand(query)
            if (localResult.matched) {
                _lastLatencyMs.value = localResult.executionLatencyMs
                _liveRouteBadge.value = "LOCAL ENGINE • ${localResult.executionLatencyMs}ms"
                _liveResponseHeadline.value = localResult.spokenResponse
                refreshTelemetryAndPermissions()

                if (localResult.requiresConfirmation && localResult.pendingConfirmation != null) {
                    _internalOrbState.value = OrbState.EXECUTING
                    _pendingConfirmation.value = localResult.pendingConfirmation
                    if (prefs.autoSpeakTts) {
                        voiceService.speakImmediate(localResult.spokenResponse)
                    }
                    memoryRepository.addMessage(
                        ChatMessageEntity(
                            role = "assistant",
                            content = "${localResult.spokenResponse}\n(${localResult.detailSummary})",
                            providerName = "Local Command Engine",
                            modelName = localResult.toolName,
                            routeCategory = TaskCategory.LOCAL_DEVICE_COMMAND.label,
                            latencyMs = localResult.executionLatencyMs
                        )
                    )
                    return@launch
                }

                _internalOrbState.value = if (localResult.isError) OrbState.ERROR else OrbState.EXECUTING
                memoryRepository.addMessage(
                    ChatMessageEntity(
                        role = "assistant",
                        content = buildString {
                            append(localResult.spokenResponse)
                            if (localResult.detailSummary.isNotBlank() && localResult.detailSummary != localResult.spokenResponse) {
                                append("\n\n")
                                append(localResult.detailSummary)
                            }
                        },
                        providerName = "Local Command Engine",
                        modelName = localResult.toolName,
                        routeCategory = TaskCategory.LOCAL_DEVICE_COMMAND.label,
                        latencyMs = localResult.executionLatencyMs,
                        isError = localResult.isError,
                        recoveryHint = localResult.recoveryHint
                    )
                )

                if (prefs.autoSpeakTts) {
                    voiceService.speakImmediate(localResult.spokenResponse)
                }
                _internalOrbState.value = OrbState.IDLE
                return@launch
            }

            // -----------------------------------------------------------------
            // STAGE 2: LOCAL RESPONSE CACHE (Instant <2ms hit if cached)
            // -----------------------------------------------------------------
            if (prefs.responseCacheEnabled && savedFact == null) {
                val cached = memoryRepository.lookupCachedResponse(query)
                if (cached != null) {
                    _lastLatencyMs.value = 1L
                    _liveRouteBadge.value = "MEMORY CACHE • 1ms (${cached.modelName})"
                    _liveResponseHeadline.value = cached.responseText
                    memoryRepository.addMessage(
                        ChatMessageEntity(
                            role = "assistant",
                            content = cached.responseText,
                            providerName = "${cached.providerName} (Cached)",
                            modelName = cached.modelName,
                            routeCategory = TaskCategory.CACHED_INSTANT.label,
                            latencyMs = 1L
                        )
                    )
                    if (prefs.autoSpeakTts) {
                        voiceService.speakImmediate(cached.responseText)
                    }
                    return@launch
                }
            }

            // -----------------------------------------------------------------
            // STAGE 3: SMART MODEL ROUTER & STREAMING CLOUD AI
            // -----------------------------------------------------------------
            _isGenerating.value = true
            _internalOrbState.value = OrbState.THINKING

            val decision = aiModelRouter.routeRequest(
                prompt = query,
                hasImageAttachment = false,
                forceResearch = false,
                routingMode = prefs.routingMode,
                preferredProvider = prefs.selectedProvider,
                preferredModelId = prefs.selectedModelId,
                isProviderConfigured = { aiService.isProviderKeyAvailable(it) }
            )

            _liveRouteBadge.value = "${decision.category.label} • ${decision.displayName}"
            _liveResponseHeadline.value = "Streaming from ${decision.displayName}..."

            // Create placeholder streaming message in Room so UI updates immediately
            val assistantMsgId = memoryRepository.addMessage(
                ChatMessageEntity(
                    role = "assistant",
                    content = "…",
                    providerName = decision.provider.displayName,
                    modelName = decision.displayName,
                    routeCategory = decision.category.label,
                    latencyMs = 0L,
                    isStreaming = true
                )
            )

            // If routed to Web Research, run grounded research pipeline
            if (decision.category == TaskCategory.WEB_RESEARCH) {
                voiceService.resetStreamingTtsBuffer()
                var previousLength = 0
                val res = webResearchService.executeResearch(
                    query = query,
                    mode = ResearchMode.FAST_SEARCH,
                    preferredProvider = decision.provider,
                    onProgressStatus = { status ->
                        _liveResponseHeadline.value = status
                    },
                    onStreamChunk = { accumulated ->
                        _liveResponseHeadline.value = accumulated
                        val delta = if (accumulated.length > previousLength) {
                            accumulated.substring(previousLength)
                        } else ""
                        previousLength = accumulated.length
                        voiceService.feedStreamingDeltaForTts(delta, prefs.autoSpeakTts)
                        memoryRepository.updateStreamingMessage(
                            id = assistantMsgId,
                            content = accumulated,
                            isStreaming = true,
                            latencyMs = 0L
                        )
                    }
                )
                voiceService.flushRemainingTtsBuffer(prefs.autoSpeakTts)
                val citationsStr = res.sources.mapIndexed { i, s -> "[${i + 1}] ${s.title} (${s.url})" }.joinToString("\n")
                memoryRepository.updateStreamingMessage(
                    id = assistantMsgId,
                    content = res.synthesisText,
                    isStreaming = false,
                    latencyMs = res.latencyMs,
                    isError = res.isError,
                    citations = citationsStr.ifBlank { null }
                )
                _lastLatencyMs.value = res.latencyMs
                _liveResponseHeadline.value = res.synthesisText
                _isGenerating.value = false
                _internalOrbState.value = if (res.isError) OrbState.ERROR else OrbState.IDLE
                return@launch
            }

            // Standard Streaming AI + Sentence-Chunked TTS
            val history = memoryRepository.getRecentConversationContext(limit = 6)
            val memoryPrompt = memoryRepository.getMemoryContextPrompt(
                memoryEnabled = prefs.memoryEnabled,
                customInstructions = prefs.customInstructions
            )

            voiceService.resetStreamingTtsBuffer()

            val outcome = aiService.streamResponse(
                provider = decision.provider,
                modelId = decision.modelId,
                prompt = query,
                history = history.filter { it.id != assistantMsgId },
                personality = prefs.personality,
                memoryContextPrompt = memoryPrompt,
                imageBitmap = null,
                onChunk = { delta, accumulated, firstTokenMs ->
                    _lastLatencyMs.value = firstTokenMs
                    _liveRouteBadge.value = "${decision.displayName} • TTFT ${firstTokenMs}ms"
                    _liveResponseHeadline.value = accumulated
                    voiceService.feedStreamingDeltaForTts(delta, prefs.autoSpeakTts)
                    memoryRepository.updateStreamingMessage(
                        id = assistantMsgId,
                        content = accumulated,
                        isStreaming = true,
                        latencyMs = firstTokenMs
                    )
                }
            )

            voiceService.flushRemainingTtsBuffer(prefs.autoSpeakTts)

            memoryRepository.updateStreamingMessage(
                id = assistantMsgId,
                content = outcome.fullText,
                isStreaming = false,
                latencyMs = outcome.firstTokenLatencyMs.coerceAtLeast(outcome.totalLatencyMs),
                isError = outcome.isError,
                recoveryHint = outcome.recoveryAction
            )

            if (!outcome.isError && prefs.responseCacheEnabled) {
                memoryRepository.cacheResponse(
                    query = query,
                    responseText = outcome.fullText,
                    providerName = decision.provider.displayName,
                    modelName = decision.displayName
                )
            }

            if (!outcome.isError && Firebase.auth.currentUser != null) {
                viewModelScope.launch {
                    cloudSyncRepository.createCloudMessage(
                        role = "assistant",
                        content = outcome.fullText,
                        providerName = decision.provider.displayName,
                        modelName = decision.displayName,
                        routeCategory = decision.category.label,
                        latencyMs = outcome.firstTokenLatencyMs.coerceAtLeast(outcome.totalLatencyMs)
                    )
                }
            }

            if (outcome.isError && prefs.autoSpeakTts) {
                voiceService.speakImmediate(outcome.errorTitle ?: "Unable to complete request.")
            }

            _liveResponseHeadline.value = outcome.fullText
            _isGenerating.value = false
            _internalOrbState.value = if (outcome.isError) OrbState.ERROR else OrbState.IDLE
            refreshTelemetryAndPermissions()
        }
    }

    // =========================================================================
    // SENSITIVE ACTION CONFIRMATION EXECUTION
    // =========================================================================
    fun confirmPendingAction() {
        val action = _pendingConfirmation.value ?: return
        _pendingConfirmation.value = null

        viewModelScope.launch {
            val prefs = userPreferences.value
            when (action) {
                is PendingConfirmationAction.PlacePhoneCall -> {
                    val res = androidControlService.executeConfirmedPhoneCall(action.phoneNumber)
                    _liveResponseHeadline.value = res.spokenText
                    if (prefs.autoSpeakTts) voiceService.speakImmediate(res.spokenText)
                }
                is PendingConfirmationAction.SendSmsMessage -> {
                    val res = androidControlService.executeConfirmedSmsCompose(action.recipient, action.messageBody)
                    _liveResponseHeadline.value = res.spokenText
                    if (prefs.autoSpeakTts) voiceService.speakImmediate(res.spokenText)
                }
                is PendingConfirmationAction.ChangeSystemSetting -> {
                    val res = androidControlService.openSystemSettingsScreen(action.settingsAction, packageSpecific = true)
                    _liveResponseHeadline.value = res.spokenText
                }
                is PendingConfirmationAction.AccessibilityClickAction -> {
                    val ok = HasseenaAccessibilityService.instance?.clickControlByLabel(action.targetElementLabel) == true
                    val msg = if (ok) "Tapped ${action.targetElementLabel}." else "Could not find ${action.targetElementLabel} on screen."
                    _liveResponseHeadline.value = msg
                    if (prefs.autoSpeakTts) voiceService.speakImmediate(msg)
                }
                is PendingConfirmationAction.ClearAllMemory -> {
                    memoryRepository.clearAllMemoryAndCache()
                    val msg = "All stored memories and cached responses have been deleted."
                    _liveResponseHeadline.value = msg
                    if (prefs.autoSpeakTts) voiceService.speakImmediate(msg)
                }
            }
            _internalOrbState.value = OrbState.IDLE
        }
    }

    fun dismissPendingConfirmation() {
        _pendingConfirmation.value = null
        _internalOrbState.value = OrbState.IDLE
        _liveResponseHeadline.value = "Action cancelled."
    }

    fun requestClearMemoryConfirmation() {
        val count = memoryFacts.value.size + cacheCount.value
        _pendingConfirmation.value = PendingConfirmationAction.ClearAllMemory(count)
    }

    // =========================================================================
    // VISUAL LENS (CAMERA / IMAGE / OCR / SCREEN ANALYSIS)
    // =========================================================================
    fun setLensBitmap(bitmap: Bitmap?) {
        _capturedLensBitmap.value = bitmap
        if (bitmap != null) {
            _lensAnalysisText.value = "Image ready. Tap an analysis mode or ask a custom question."
        }
    }

    fun analyzeVisualLensImage(prompt: String) {
        val bitmap = _capturedLensBitmap.value
        if (bitmap == null) {
            _lensAnalysisText.value = "Capture a photo with the camera or select an image first."
            return
        }

        cancelActiveGeneration()
        voiceService.stopSpeakingImmediately()

        activeGenerationJob = viewModelScope.launch {
            val prefs = userPreferences.value
            _isLensAnalyzing.value = true
            _internalOrbState.value = OrbState.THINKING
            _lensAnalysisText.value = "Analyzing image with Gemini 3.8 Flash Vision..."
            voiceService.resetStreamingTtsBuffer()

            val outcome = aiService.streamResponse(
                provider = AIProviderType.GEMINI,
                modelId = "gemini-3.8-flash",
                prompt = prompt,
                history = emptyList(),
                personality = prefs.personality,
                memoryContextPrompt = "",
                imageBitmap = bitmap,
                onChunk = { delta, accumulated, firstTokenMs ->
                    _lastLatencyMs.value = firstTokenMs
                    _lensAnalysisText.value = accumulated
                    voiceService.feedStreamingDeltaForTts(delta, prefs.autoSpeakTts)
                }
            )

            voiceService.flushRemainingTtsBuffer(prefs.autoSpeakTts)
            _lensAnalysisText.value = outcome.fullText
            _isLensAnalyzing.value = false
            _internalOrbState.value = if (outcome.isError) OrbState.ERROR else OrbState.IDLE

            memoryRepository.addMessage(
                ChatMessageEntity(
                    role = "assistant",
                    content = "**[Visual Lens: $prompt]**\n${outcome.fullText}",
                    providerName = "Google Gemini",
                    modelName = "Gemini 3.8 Flash Vision",
                    routeCategory = TaskCategory.VISION_ANALYSIS.label,
                    latencyMs = outcome.firstTokenLatencyMs,
                    isError = outcome.isError,
                    recoveryHint = outcome.recoveryAction
                )
            )
        }
    }

    fun analyzeActiveScreenWithAccessibility() {
        val a11y = HasseenaAccessibilityService.instance
        if (a11y == null) {
            _lensAnalysisText.value = "Accessibility Service is currently disabled. Enable 'JARVIS Screen & Action Assistant' in the Permission Center to read and analyze on-screen UI content."
            return
        }
        val snapshot = a11y.readVisibleScreenContent()
        if (!snapshot.available || snapshot.visibleTexts.isEmpty()) {
            _lensAnalysisText.value = snapshot.summary
            return
        }

        cancelActiveGeneration()
        activeGenerationJob = viewModelScope.launch {
            val prefs = userPreferences.value
            _isLensAnalyzing.value = true
            _internalOrbState.value = OrbState.THINKING
            val screenPrompt = "Analyze the following visible Android screen content from package '${snapshot.packageName}':\n" +
                "Visible text: ${snapshot.visibleTexts.joinToString(" | ")}\n" +
                "Interactive controls: ${snapshot.clickableLabels.joinToString(", ")}\n" +
                "Provide a concise summary of what is on the user's screen and what actions they can take."

            voiceService.resetStreamingTtsBuffer()
            val outcome = aiService.streamResponse(
                provider = prefs.selectedProvider,
                modelId = prefs.selectedModelId,
                prompt = screenPrompt,
                history = emptyList(),
                personality = prefs.personality,
                memoryContextPrompt = "",
                imageBitmap = null,
                onChunk = { delta, accumulated, _ ->
                    _lensAnalysisText.value = accumulated
                    voiceService.feedStreamingDeltaForTts(delta, prefs.autoSpeakTts)
                }
            )
            voiceService.flushRemainingTtsBuffer(prefs.autoSpeakTts)
            _lensAnalysisText.value = outcome.fullText
            _isLensAnalyzing.value = false
            _internalOrbState.value = OrbState.IDLE
        }
    }

    // =========================================================================
    // WEB & DEEP RESEARCH
    // =========================================================================
    fun setResearchMode(mode: ResearchMode) {
        _researchMode.value = mode
    }

    fun runWebResearch(query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return

        cancelActiveGeneration()
        voiceService.stopSpeakingImmediately()

        activeGenerationJob = viewModelScope.launch {
            val prefs = userPreferences.value
            _isResearching.value = true
            _internalOrbState.value = OrbState.THINKING
            _researchSummary.value = ""
            _researchSources.value = emptyList()
            voiceService.resetStreamingTtsBuffer()
            var prevLen = 0

            val res = webResearchService.executeResearch(
                query = trimmed,
                mode = _researchMode.value,
                preferredProvider = prefs.selectedProvider,
                onProgressStatus = { status ->
                    _researchStatus.value = status
                },
                onStreamChunk = { accumulated ->
                    _researchSummary.value = accumulated
                    val delta = if (accumulated.length > prevLen) accumulated.substring(prevLen) else ""
                    prevLen = accumulated.length
                    voiceService.feedStreamingDeltaForTts(delta, prefs.autoSpeakTts)
                }
            )

            voiceService.flushRemainingTtsBuffer(prefs.autoSpeakTts)
            _researchSummary.value = res.synthesisText
            _researchSources.value = res.sources
            _researchStatus.value = "Completed in ${res.latencyMs}ms • ${res.sources.size} verified sources"
            _lastLatencyMs.value = res.latencyMs
            _isResearching.value = false
            _internalOrbState.value = if (res.isError) OrbState.ERROR else OrbState.IDLE
        }
    }

    // =========================================================================
    // SETTINGS & PREFERENCES UPDATES
    // =========================================================================
    fun updateOrbConfig(config: OrbConfig) {
        viewModelScope.launch {
            preferencesRepository.setOrbConfig(config)
        }
    }

    fun testApiKey(
        provider: AIProviderType,
        key: String,
        onResult: (String) -> Unit
    ) {
        viewModelScope.launch {
            val result = aiService.testApiKey(provider, key)
            onResult(result)
        }
    }

    fun updateProviderAndModel(provider: AIProviderType, modelId: String) {
        viewModelScope.launch {
            preferencesRepository.setProviderAndModel(provider, modelId)
        }
    }

    fun updateRoutingMode(mode: RoutingMode) {
        viewModelScope.launch {
            preferencesRepository.setRoutingMode(mode)
        }
    }

    fun updatePersonality(personality: AssistantPersonality) {
        viewModelScope.launch {
            preferencesRepository.setPersonality(personality)
        }
    }

    fun updateMemoryEnabled(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setMemoryEnabled(enabled)
        }
    }

    fun updateCacheEnabled(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setResponseCacheEnabled(enabled)
        }
    }

    fun updateCustomInstructions(instructions: String) {
        viewModelScope.launch {
            preferencesRepository.setCustomInstructions(instructions)
        }
    }

    fun updateWakeWordConfig(enabled: Boolean, phrase: String) {
        viewModelScope.launch {
            preferencesRepository.setWakeWordConfig(enabled, phrase)
        }
    }

    fun updateVoicePreferences(
        continuous: Boolean,
        autoSpeak: Boolean,
        bargeIn: Boolean,
        haptics: Boolean
    ) {
        viewModelScope.launch {
            preferencesRepository.setVoiceSettings(continuous, autoSpeak, bargeIn, haptics)
        }
    }

    fun addMemoryFact(category: String, content: String) {
        viewModelScope.launch {
            memoryRepository.addMemoryFact(category, content, "Manual Entry")
            if (Firebase.auth.currentUser != null) {
                val res = cloudSyncRepository.createCloudMemory(category, content, "Manual Entry")
                _cloudSyncStatus.value = if (res.isSuccess) {
                    "Synced memory fact to Cloud Firestore."
                } else {
                    "Saved locally; cloud sync error: ${res.exceptionOrNull()?.localizedMessage ?: "unknown"}"
                }
            }
        }
    }

    fun syncLocalMemoriesToCloud() {
        viewModelScope.launch {
            if (Firebase.auth.currentUser == null) {
                _cloudSyncStatus.value = "Sign in with Google to sync memories to Cloud Firestore."
                return@launch
            }
            val localFacts = memoryFacts.value
            val cloudExisting = cloudMemories.value.map { it.content.trim().lowercase() }.toSet()
            var uploaded = 0
            for (fact in localFacts) {
                if (fact.content.trim().lowercase() !in cloudExisting) {
                    val res = cloudSyncRepository.createCloudMemory(fact.category, fact.content, fact.source)
                    if (res.isSuccess) uploaded++
                }
            }
            _cloudSyncStatus.value = if (uploaded > 0) {
                "Synced $uploaded memory fact(s) to Cloud Firestore."
            } else {
                "All ${cloudMemories.value.size} memory facts are up to date in Cloud Firestore."
            }
        }
    }

    fun deleteMemoryFact(id: Long) {
        viewModelScope.launch {
            memoryRepository.deleteMemoryFact(id)
        }
    }

    fun clearAllConversations() {
        viewModelScope.launch {
            memoryRepository.clearConversations()
            _liveResponseHeadline.value = "Conversation history cleared."
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceService.release()
    }
}
