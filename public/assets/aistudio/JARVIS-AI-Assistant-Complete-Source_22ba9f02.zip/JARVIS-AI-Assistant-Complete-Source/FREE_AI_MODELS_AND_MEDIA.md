# Hasseena AI — AI model and media notes

## Current model catalog notes

The current app catalog has **23 model entries** across the configured providers. These requested model integrations are included:

- Kimi K2.6: `moonshotai/kimi-k2.6` — paid OpenRouter model; do not assume a free endpoint. [OpenRouter model page](https://openrouter.ai/moonshotai/kimi-k2.6)
- NVIDIA Nemotron 3.5 Lightning: `nvidia/nemotron-3.5-lightning-30b-a3b` through NVIDIA NIM — NVIDIA lists a free trial endpoint, subject to account eligibility and quota. [NVIDIA model page](https://build.nvidia.com/nvidia/nemotron-3.5-lightning-30b-a3b)
- Gemini 3.8 Flash: `gemini-3.8-flash` — use the Google AI Studio key saved in Settings; free-tier access depends on the account and current quota.
- GPT-OSS 120B (Groq): `openai/gpt-oss-120b` — Groq API access is subject to its published token pricing and account limits.

Kimi uses the OpenRouter provider and its manually entered API key; Nemotron 3.5 Lightning uses the NVIDIA NIM provider and requires its own API key. No keys are bundled. The catalog entries are selectable, but live provider access and a successful Android build/device test have not been verified in this packaging environment.

This source update adds OpenRouter as an optional OpenAI-compatible provider and includes three example free-tier model IDs in the model selector:

- `qwen/qwen3-coder:free` — coding tasks
- `deepseek/deepseek-r1:free` — reasoning/debugging
- `meta-llama/llama-3.3-70b-instruct:free` — general chat

Free model availability, IDs, rate limits, and capacity can change. If a model is no longer listed as free, choose a currently `:free` model in the OpenRouter model directory and update the model ID. Create your own key at https://openrouter.ai/keys and add it in Hasseena Settings → AI & Router → OpenRouter. The app stores entered provider keys using Android Keystore-backed encryption. No API key is bundled in this ZIP.

## Image generation

A text/chat API key does not automatically enable image generation. For a free-tier image API, create a Hugging Face token at https://huggingface.co/settings/tokens and choose an image-generation model whose current Inference Providers page explicitly offers free usage. Availability and free credits are limited and may change. The existing Visual Lens feature analyzes images; it is not the same as generating new images.

## Video generation

There is no reliable promise of unlimited, permanently free hosted text-to-video generation. Providers commonly offer trial credits or charge per generated second. Check the current quota/pricing before integrating a provider; do not label a paid endpoint “free”. This source update does not claim that image or video generation is already wired into the app UI.

## Security and usage

- Keep keys private; never paste them into public GitHub repositories or screenshots.
- A free API key can still have daily quotas and rate limits (HTTP 429).
- Provider free-tier terms can restrict commercial use and may process prompts externally.
- OpenRouter calls use the OpenAI-compatible chat-completions endpoint. Model IDs above are examples and may need updating if providers change availability.

## API key links

- Google Gemini: https://aistudio.google.com/app/apikey
- Groq: https://console.groq.com/keys
- OpenRouter: https://openrouter.ai/keys
- Hugging Face: https://huggingface.co/settings/tokens

## Additional providers in this update

- NVIDIA NIM: `meta/llama-3.3-70b-instruct` (general chat) and `qwen/qwen2.5-coder-32b-instruct` (coding) are added as model choices. Create a key at https://build.nvidia.com/ and verify each model is currently enabled for your account.
- Mistral AI: `mistral-small-latest` and `codestral-latest` are added as model choices. Create a key at https://console.mistral.ai/api-keys/ and verify Experiment/free-tier eligibility in your account.

These are free-tier/experiment options, not a guarantee of unlimited permanent free use. Provider terms, model access, and quotas can change; the app's **TEST KEY** button should be used after adding a key. If a provider removes free access or a model ID, select a currently available model or remove that provider from use. The new providers use the existing encrypted manual-key manager and existing OpenAI-compatible streaming path.

Additional AI models added (API key required in Settings):
- Google Gemini 3.8 Flash — model ID `gemini-3.8-flash`; Google AI Studio free-tier access and quotas depend on current account/model availability.
- GPT-OSS 120B via Groq — model ID `openai/gpt-oss-120b`; Groq publishes token pricing, so do not treat it as guaranteed free.
These entries are selectable through the existing provider/model selector. No API keys are embedded in source.
