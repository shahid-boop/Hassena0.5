# Hasseena AI targeted upgrade report — 2026-10-14

## Preservation
- All 98 original archive files remain present; no original file was removed.
- One new Kotlin file was added for File Workspace and the user-enabled floating overlay.
- Existing Kotlin/Jetpack Compose architecture and the current manual API-key store were retained.

## Implemented in this update
- Added a File Workspace navigation destination and Compose screen.
- Android Storage Access Framework import supports arbitrary user-selected files without broad storage permissions.
- Individual file export, code/text file creation, safe relative ZIP entry paths, duplicate-name handling, and ZIP export to a user-selected destination.
- Added an explicit floating Orb start/stop control. The service requests the Android "display over other apps" special-access grant, draws a draggable holographic Orb, opens Hasseena on tap, and shows an ongoing foreground-service notification while enabled.
- Extended the AI router to prefer configured providers, respect catalog-declared vision/research capabilities, route coding/reasoning prompts to a reasoning tier, and explain when an API key is missing. It continues to use the existing manual API-key configuration.
- Extended GLTF/GLB loading to apply scene node matrix or translation/rotation/scale transforms while keeping existing mobile file/vertex limits.
- Added the required overlay and special-use foreground service manifest declarations.

## Limitations that must not be represented as completed
- This File Workspace imports files into the workspace and exports them individually or as a ZIP. It does not yet extract/import ZIP archives, automatically send arbitrary PDF/video contents to the AI, or turn a natural-language prompt into a multi-file generated project automatically. Code/text can be added manually and exported with other files.
- Current GLTF loader still focuses on triangle positions/normals and self-contained/embedded buffers. Imported glTF external buffers, PBR material/texture maps, skeletal/clip animation, true HDR image-based lighting, real shadow maps, and full ARCore camera/depth compositing are not completed by this patch. Existing renderer has shader-based studio reflections and bloom-style tone mapping, not a complete HDR/shadow pipeline.
- Floating Orb requires the user to grant "Display over other apps". Android may stop services under battery/background restrictions; device-level testing is required.
- Existing project archive does not include `google-services.json`; keep the valid file in the user's working project if Firebase build/runtime requires it.

## Verification
- Original ZIP integrity: passed before changes.
- Original-file preservation check: 98 original files found; zero missing.
- AndroidManifest.xml XML parse: passed.
- Gradle build in this execution environment: not verified because Gradle 9.6.0 distribution download failed with `UnknownHostException: services.gradle.org`. This is a network/DNS limitation, not evidence of a Kotlin compile result. Build and runtime testing in Termux remain required.
